require 'rubygems'
require 'test/unit'
require 'fakeweb'
require File.dirname(__FILE__) + '/../lib/firstfm'